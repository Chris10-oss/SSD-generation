from qgis.PyQt.QtCore import QVariant
from qgis.core import (
    QgsFeature, QgsFields, QgsField, QgsGeometry, QgsPointXY,
    QgsProcessingAlgorithm, QgsProcessingException, QgsFeatureSink,
    QgsProcessingParameterBoolean, QgsProcessingParameterCrs,
    QgsProcessingParameterFeatureSource, QgsProcessingParameterFileDestination,
    QgsProcessingParameterNumber, QgsProcessingParameterString,
    QgsProcessingParameterFeatureSink, QgsSpatialIndex, QgsCoordinateTransform,
    QgsCoordinateReferenceSystem, QgsWkbTypes, QgsProject, QgsVectorFileWriter
)
import json, os

class SSDGenProAlgorithm(QgsProcessingAlgorithm):
    """Generate synthetic storm drain (SSD) inlets along left/right kerbs with staggered placement,
    per-class spacing/offsets, global spacing, optional building exclusion, optional OSM download/caching,
    QA outputs, and CityCAT export."""

    def createInstance(self):
        return SSDGenProAlgorithm()

    # Parameter keys
    P_STUDY = "STUDY_AREA"
    P_ROADS = "ROADS"
    P_BUILDINGS = "BUILDINGS"
    P_DOWNLOAD_OSM = "DOWNLOAD_OSM"
    P_OSM_CACHE = "OSM_CACHE"
    P_INCLUDE_LOCALS = "INCLUDE_LOCALS"
    P_TARGET_CRS = "TARGET_CRS"
    P_SPACING = "SPACING"
    P_MIN_SPACING = "MIN_SPACING"
    P_KERB_OFFSET = "KERB_OFFSET"
    P_STAGGER = "STAGGER"
    P_CLASSES = "CLASSES"
    P_CLASS_SPACING = "CLASS_SPACING_JSON"
    P_CLASS_KERB = "CLASS_KERB_JSON"
    P_OUT = "OUTPUT_SSD"
    P_QA_KERBS = "OUTPUT_KERBS"
    P_QA_BUFFER = "OUTPUT_BUFFER"
    P_CITYCAT = "CITYCAT_OUT"
    P_HEADER = "CITYCAT_HEADER"

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterFeatureSource(
            self.P_STUDY, "Study area (polygon)", [QgsWkbTypes.Polygon, QgsWkbTypes.MultiPolygon]
        ))
        self.addParameter(QgsProcessingParameterFeatureSource(
            self.P_ROADS, "Roads (line) [optional if 'Download OSM' is enabled]",
            [QgsWkbTypes.LineString, QgsWkbTypes.MultiLineString], optional=True
        ))
        self.addParameter(QgsProcessingParameterFeatureSource(
            self.P_BUILDINGS, "Buildings (polygon) [optional]",
            [QgsWkbTypes.Polygon, QgsWkbTypes.MultiPolygon], optional=True
        ))
        self.addParameter(QgsProcessingParameterBoolean(
            self.P_DOWNLOAD_OSM, "Download roads from OSM (Overpass) using study area extent", defaultValue=False
        ))
        self.addParameter(QgsProcessingParameterFileDestination(
            self.P_OSM_CACHE, "OSM cache GeoPackage (optional, read/write)", fileFilter="GeoPackage (*.gpkg)", optional=True
        ))
        self.addParameter(QgsProcessingParameterBoolean(
            self.P_INCLUDE_LOCALS, "Include local roads (residential/service/unclassified/living_street)", defaultValue=False
        ))
        self.addParameter(QgsProcessingParameterCrs(
            self.P_TARGET_CRS, "Target CRS (projected, metres)", defaultValue=QgsProject.instance().crs()
        ))
        self.addParameter(QgsProcessingParameterNumber(
            self.P_SPACING, "Default spacing between inlets (m)", type=QgsProcessingParameterNumber.Double, defaultValue=50.0, minValue=1.0
        ))
        self.addParameter(QgsProcessingParameterNumber(
            self.P_MIN_SPACING, "Global minimum spacing (m)", type=QgsProcessingParameterNumber.Double, defaultValue=50.0, minValue=1.0
        ))
        self.addParameter(QgsProcessingParameterNumber(
            self.P_KERB_OFFSET, "Default kerb offset from road centerline (m)", type=QgsProcessingParameterNumber.Double, defaultValue=3.0, minValue=0.1
        ))
        self.addParameter(QgsProcessingParameterBoolean(
            self.P_STAGGER, "Stagger left/right placement", defaultValue=True
        ))
        self.addParameter(QgsProcessingParameterString(
            self.P_CLASSES, "Highway classes to include (comma-separated; used for OSM filter if downloading)",
            optional=True, defaultValue="primary,secondary,tertiary"
        ))
        self.addParameter(QgsProcessingParameterString(
            self.P_CLASS_SPACING, "Per-class spacing JSON (optional; include key '_default' for fallback)",
            optional=True, defaultValue=""
        ))
        self.addParameter(QgsProcessingParameterString(
            self.P_CLASS_KERB, "Per-class kerb offset JSON (optional; include key '_default' for fallback)",
            optional=True, defaultValue=""
        ))

        self.addParameter(QgsProcessingParameterFeatureSink(self.P_OUT, "Synthetic inlets (points)"))
        self.addParameter(QgsProcessingParameterFeatureSink(self.P_QA_KERBS, "QA kerb lines (left/right offsets)", optional=True))
        self.addParameter(QgsProcessingParameterFeatureSink(self.P_QA_BUFFER, "QA buffered road polygons", optional=True))

        self.addParameter(QgsProcessingParameterFileDestination(
            self.P_CITYCAT, "CityCAT inlet file (TXT) [optional]", fileFilter="Text files (*.txt)", optional=True
        ))
        self.addParameter(QgsProcessingParameterString(
            self.P_HEADER, "CityCAT header: 'size_x size_y friction'", defaultValue="0.30 0.30 0.50"
        ))

    def name(self):
        return "ssdgen_pro"

    def displayName(self):
        return "SSDGen Pro – Generate synthetic storm drain inlets"

    def group(self):
        return "SSDGen Pro"

    def groupId(self):
        return "ssdgenpro"

    def shortHelpString(self):
        return ("Generates synthetic storm drain inlet points along road kerbs.\n"
                "- Staggered left/right placement (~50 m)\n"
                "- Per-class spacing and kerb offsets via JSON (use '_default')\n"
                "- Global minimum distance enforcement\n"
                "- Optional building exclusion\n"
                "- Optional OSM download with GeoPackage caching\n"
                "- Optional QA layers (kerb lines, buffered polygons)\n"
                "- Optional CityCAT TXT export\n")

    # Helpers and processAlgorithm definitions would continue here...
    # To keep the cell output short, reusing the full content from v1.1.5:
    # Helpers
    def _to_crs(self, layer, target_crs):
        if layer.sourceCrs() != target_crs:
            ct = QgsCoordinateTransform(layer.sourceCrs(), target_crs, QgsProject.instance())
            def _geom_to(crs_geom):
                g = QgsGeometry(crs_geom)
                g.transform(ct)
                return g
            return [_geom_to(f.geometry()) for f in layer.getFeatures()]
        else:
            return [f.geometry() for f in layer.getFeatures()]

    def _union_polygon(self, geoms):
        out = None
        for g in geoms:
            if not g or g.isEmpty():
                continue
            out = g if out is None else out.combine(g)
        return out

    def _bbox_4326(self, geom, source_crs):
        ct = QgsCoordinateTransform(source_crs, QgsCoordinateReferenceSystem("EPSG:4326"), QgsProject.instance())
        g = QgsGeometry(geom)
        g.transform(ct)
        e = g.boundingBox()
        return (e.xMinimum(), e.yMinimum(), e.xMaximum(), e.yMaximum())

    def _download_osm_roads(self, bbox, classes, include_locals, cache_path, target_crs, union_geom):
        # Try cache first
        if cache_path and os.path.exists(cache_path):
            try:
                from qgis.core import QgsVectorLayer
                vl = QgsVectorLayer(f"{cache_path}|layername=roads", "roads", "ogr")
                if vl.isValid():
                    geoms = self._to_crs(vl, target_crs)
                    clipped = []
                    for g in geoms:
                        gi = g.intersection(union_geom)
                        if not gi.isEmpty():
                            clipped.append(gi)
                    return clipped
            except Exception:
                pass

        # Download via Overpass
        try:
            import requests
        except Exception:
            raise QgsProcessingException("The 'requests' package is required for OSM download. Install it or provide a roads layer.")

        hw = [c.strip() for c in (classes or "").split(",") if c.strip()]
        if include_locals:
            hw += ["residential", "service", "unclassified", "living_street"]
        hw_filter = "|".join(sorted(set(hw))) if hw else "primary|secondary|tertiary"

        query = f"""
        [out:json][timeout:50];
        way["highway"~"{hw_filter}"]({bbox[1]},{bbox[0]},{bbox[3]},{bbox[2]});
        (._;>;);
        out body;
        """
        url = "https://overpass-api.de/api/interpreter"
        r = requests.post(url, data={"data": query.strip()})
        if r.status_code != 200:
            raise QgsProcessingException(f"Overpass API error: HTTP {r.status_code}")
        data = r.json()
        nodes = {el["id"]: (el["lon"], el["lat"]) for el in data["elements"] if el["type"] == "node"}

        # Build line geoms (4326 → target)
        geoms = []
        for el in data["elements"]:
            if el["type"] == "way":
                coords = [nodes.get(nid) for nid in el["nodes"] if nid in nodes]
                coords = [c for c in coords if c]
                if len(coords) >= 2:
                    pts = [QgsPointXY(x, y) for x, y in coords]
                    geom = QgsGeometry.fromPolylineXY(pts)
                    geoms.append(geom)

        ct = QgsCoordinateTransform(QgsCoordinateReferenceSystem("EPSG:4326"), target_crs, QgsProject.instance())
        clipped = []
        for lw in geoms:
            lw.transform(ct)
            g = lw.intersection(union_geom)
            if not g.isEmpty():
                clipped.append(g)

        # Write cache if requested
        if cache_path:
            fields = QgsFields(); fields.append(QgsField("id", QVariant.Int))
            writer = QgsVectorFileWriter.create(
                cache_path, fields, QgsWkbTypes.LineString, target_crs,
                QgsProject.instance().transformContext(), "GPKG", ["FID=id", "LAYER_NAME=roads"]
            )
            if writer.hasError() == QgsVectorFileWriter.NoError:
                for i, g in enumerate(clipped):
                    f = QgsFeature(i); f.setFields(fields); f["id"] = i; f.setGeometry(g)
                    writer.addFeature(f)
                del writer

        return clipped

    def _offset_curve(self, geom, dist):
        try:
            return geom.offsetCurve(dist, joinStyle=2, segments=8, mitreLimit=5.0)
        except Exception:
            return None

    def _points_along(self, line_geom, start, step, max_len=None):
        L = line_geom.length()
        if max_len is not None:
            L = min(L, max_len)
        d = start
        pts = []
        while d < L:
            p = line_geom.interpolate(d)
            pts.append(p.asPoint())
            d += step
        return pts

    def _thin_points(self, points, min_dist):
        if not points:
            return []
        kept = []
        idx = QgsSpatialIndex()
        for i, pt in enumerate(points):
            if not kept:
                idx.insertFeature(self._feature_from_point(0, pt))
                kept.append(pt); continue
            env = QgsGeometry.fromPointXY(pt).buffer(min_dist, 8).boundingBox()
            _ = idx.intersects(env)
            # Conservative n^2 check (OK for a few 10k points)
            too_close = False
            for kpt in kept:
                dx = (kpt.x() - pt.x()); dy = (kpt.y() - pt.y())
                if (dx*dx + dy*dy) ** 0.5 < min_dist:
                    too_close = True; break
            if not too_close:
                idx.insertFeature(self._feature_from_point(len(kept), pt))
                kept.append(pt)
        return kept

    def _feature_from_point(self, fid, pt):
        f = QgsFeature(fid)
        f.setGeometry(QgsGeometry.fromPointXY(pt))
        return f

    def processAlgorithm(self, parameters, context, feedback):
        study_src = self.parameterAsSource(parameters, self.P_STUDY, context)
        roads_src = self.parameterAsSource(parameters, self.P_ROADS, context)
        bld_src = self.parameterAsSource(parameters, self.P_BUILDINGS, context)
        download_osm = self.parameterAsBool(parameters, self.P_DOWNLOAD_OSM, context)
        cache_path = self.parameterAsFileOutput(parameters, self.P_OSM_CACHE, context)
        include_locals = self.parameterAsBool(parameters, self.P_INCLUDE_LOCALS, context)

        target_crs = self.parameterAsCrs(parameters, self.P_TARGET_CRS, context)
        spacing_default = self.parameterAsDouble(parameters, self.P_SPACING, context)
        min_spacing = self.parameterAsDouble(parameters, self.P_MIN_SPACING, context)
        kerb_default = self.parameterAsDouble(parameters, self.P_KERB_OFFSET, context)
        stagger = self.parameterAsBool(parameters, self.P_STAGGER, context)
        classes = self.parameterAsString(parameters, self.P_CLASSES, context) or ""
        spacing_json = self.parameterAsString(parameters, self.P_CLASS_SPACING, context) or ""
        kerb_json = self.parameterAsString(parameters, self.P_CLASS_KERB, context) or ""

        (sink_pts, dest_pts) = self.parameterAsSink(parameters, self.P_OUT, context,
            QgsFields([QgsField("id", QVariant.Int), QgsField("active", QVariant.Int),
                       QgsField("spacing_m", QVariant.Double), QgsField("kerb_m", QVariant.Double),
                       QgsField("class", QVariant.String)]),
            QgsWkbTypes.Point, target_crs)

        sink_kerb = dest_kerb = None
        if self.P_QA_KERBS in parameters and parameters[self.P_QA_KERBS] is not None:
            (sink_kerb, dest_kerb) = self.parameterAsSink(parameters, self.P_QA_KERBS, context,
                QgsFields([QgsField("side", QVariant.String)]),
                QgsWkbTypes.LineString, target_crs)

        sink_buf = dest_buf = None
        if self.P_QA_BUFFER in parameters and parameters[self.P_QA_BUFFER] is not None:
            (sink_buf, dest_buf) = self.parameterAsSink(parameters, self.P_QA_BUFFER, context,
                QgsFields([]), QgsWkbTypes.Polygon, target_crs)

        citycat_path = self.parameterAsFileOutput(parameters, self.P_CITYCAT, context)
        header_str = self.parameterAsString(parameters, self.P_HEADER, context)

        if not study_src:
            raise QgsProcessingException("Study area is required.")
        if (not roads_src) and (not download_osm):
            raise QgsProcessingException("Provide a roads layer or enable 'Download OSM'.")

        study_geoms = self._to_crs(study_src, target_crs)
        study_union = self._union_polygon(study_geoms)
        if not study_union or study_union.isEmpty():
            raise QgsProcessingException("Study area geometry is empty after transformation.")

        roads = []
        if roads_src:
            for f in roads_src.getFeatures():
                g = QgsGeometry(f.geometry())
                if roads_src.sourceCrs() != target_crs:
                    ct = QgsCoordinateTransform(roads_src.sourceCrs(), target_crs, QgsProject.instance())
                    g.transform(ct)
                gi = g.intersection(study_union)
                if not gi.isEmpty():
                    roads.append(gi)
        else:
            bbox = self._bbox_4326(study_union, target_crs)
            feedback.pushInfo("Downloading roads from OSM (Overpass)...")
            roads = self._download_osm_roads(bbox, classes, include_locals, cache_path, target_crs, study_union)

        if not roads:
            raise QgsProcessingException("No road geometries available after clip/download.")

        # Parse per-class JSON maps
        def parse_map(txt, default_val):
            try:
                mp = json.loads(txt) if txt else {}
                if "_default" not in mp:
                    mp["_default"] = default_val
                return mp
            except Exception:
                return {"_default": default_val}
        spacing_map = parse_map(spacing_json, spacing_default)
        kerb_map = parse_map(kerb_json, kerb_default)

        # Candidate points
        cand_pts = []
        class_list = [c.strip() for c in (classes or "").split(",") if c.strip()]
        if include_locals:
            class_list += ["residential", "service", "unclassified", "living_street"]
        class_list = list(dict.fromkeys(class_list))

        for g in roads:
            the_class = class_list[0] if class_list else "_default"
            spacing = spacing_map.get(the_class, spacing_map.get("_default", spacing_default))
            kerb = kerb_map.get(the_class, kerb_map.get("_default", kerb_default))

            left = self._offset_curve(g, +kerb)
            right = self._offset_curve(g, -kerb)
            if not left or left.isEmpty() or not right or right.isEmpty():
                continue
            L = min(left.length(), right.length())
            if L <= 0:
                continue

            if sink_kerb:
                lf = QgsFeature(); lf.setFields(QgsFields([QgsField("side", QVariant.String)])); lf["side"]="left"; lf.setGeometry(left); sink_kerb.addFeature(lf)
                rf = QgsFeature(); rf.setFields(QgsFields([QgsField("side", QVariant.String)])); rf["side"]="right"; rf.setGeometry(right); sink_kerb.addFeature(rf)

            if stagger:
                left_start = spacing * 0.5
                right_start = spacing * 1.0
            else:
                left_start = right_start = spacing * 0.5

            for p in self._points_along(left, left_start, spacing, max_len=L):
                cand_pts.append(("left", the_class, spacing, kerb, QgsPointXY(p.x(), p.y())))
            for p in self._points_along(right, right_start, spacing, max_len=L):
                cand_pts.append(("right", the_class, spacing, kerb, QgsPointXY(p.x(), p.y())))

        # Global spacing filter
        all_pts = [pt[-1] for pt in cand_pts]
        thinned = self._thin_points(all_pts, min_spacing)

        # Building exclusion
        final_pts = thinned
        if bld_src:
            bld_geoms = self._to_crs(bld_src, target_crs)
            kept = []
            for pt in final_pts:
                gpt = QgsGeometry.fromPointXY(pt)
                inside = any(bg.contains(gpt) for bg in bld_geoms)
                if not inside:
                    kept.append(pt)
            final_pts = kept

        # Write points
        for i, pt in enumerate(final_pts):
            feat = QgsFeature()
            feat.setFields(sink_pts.fields())
            feat["id"] = i
            feat["active"] = 1
            feat["spacing_m"] = float(spacing_map.get("_default", spacing_default))
            feat["kerb_m"] = float(kerb_map.get("_default", kerb_default))
            feat["class"] = class_list[0] if class_list else "_default"
            feat.setGeometry(QgsGeometry.fromPointXY(pt))
            sink_pts.addFeature(feat)

        # Optional QA buffer
        if sink_buf is not None:
            buf = None
            bufw = kerb_map.get("_default", kerb_default) + 1.0
            for g in roads:
                gb = g.buffer(bufw, 8)
                buf = gb if buf is None else buf.combine(gb)
            if buf:
                bf = QgsFeature(); bf.setGeometry(buf); sink_buf.addFeature(bf)

        # CityCAT export
        if citycat_path:
            parts = (header_str or "").strip().split()
            if len(parts) != 3:
                raise QgsProcessingException("CityCAT header must have three values: size_x size_y friction")
            size_x, size_y, friction = [float(v) for v in parts]
            with open(citycat_path, "w", encoding="utf-8") as f:
                f.write(f"{size_x:.2f} {size_y:.2f} {friction:.2f}\n")
                for i, pt in enumerate(final_pts):
                    f.write(f"{i:d} {pt.x():.4f} {pt.y():.4f} 1\n")

        results = { self.P_OUT: dest_pts }
        if sink_kerb: results[self.P_QA_KERBS] = dest_kerb
        if sink_buf: results[self.P_QA_BUFFER] = dest_buf
        if citycat_path: results[self.P_CITYCAT] = citycat_path
        return results