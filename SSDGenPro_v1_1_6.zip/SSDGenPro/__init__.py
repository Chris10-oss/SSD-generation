def classFactory(iface):
    from .ssdgen_pro_plugin import SSDGenProPlugin
    return SSDGenProPlugin(iface)
