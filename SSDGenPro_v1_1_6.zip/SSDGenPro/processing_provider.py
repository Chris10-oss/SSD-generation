from qgis.core import QgsProcessingProvider
from .algorithms.ssdgen_pro_algorithm import SSDGenProAlgorithm

class SSDGenProProvider(QgsProcessingProvider):
    def loadAlgorithms(self, *args, **kwargs):
        self.addAlgorithm(SSDGenProAlgorithm())

    def id(self):
        return "ssdgenpro"

    def name(self):
        return "SSDGen Pro"

    def longName(self):
        return "SSDGen Pro – Synthetic Storm Drain Generator"
